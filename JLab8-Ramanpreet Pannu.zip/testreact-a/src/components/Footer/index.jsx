export default function Footer() {
  return (
    <footer id="footer">
      <div>&copy; Copyright HTTP5222, 2024.</div>
    </footer>
  );
}
